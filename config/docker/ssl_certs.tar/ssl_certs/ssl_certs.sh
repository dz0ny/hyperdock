#!/bin/bash

shopt -s extglob

usage() {
    cat <<EOF
usage: $0 option

OPTIONS:
   help       Show this message
   clean      Clean up
   generate   Generate SSL certificates for Docker
EOF
}

clean() {
    rm -rf client server ssl.json
    if [ -d "docker_ca" ]; then
        cd docker_ca
        rm -rf !(openssl.cnf)
    fi
}

generate() {
    mkdir -p client server docker_ca/private docker_ca/certs
    touch docker_ca/index.txt
    echo 01 > docker_ca/serial
    cd docker_ca
    openssl req -x509 -config openssl.cnf -newkey rsa:2048 -days 1825 -out cacert.pem -outform PEM -subj /CN=DockerCA/ -nodes
    openssl x509 -in cacert.pem -out cacert.cer -outform DER
    cd ../server
    openssl genrsa -out key.pem 2048
    openssl req -new -key key.pem -out req.pem -outform PEM -subj /CN=docker/O=server/ -nodes
    cd ../docker_ca
    openssl ca -config openssl.cnf -in ../server/req.pem -out ../server/cert.pem -notext -batch -extensions server_ca_extensions
    cd ../server
    openssl pkcs12 -export -out keycert.p12 -in cert.pem -inkey key.pem -passout pass:secret
    cd ../client
    openssl genrsa -out key.pem 2048
    openssl req -new -key key.pem -out req.pem -outform PEM -subj /CN=docker/O=client/ -nodes
    cd ../docker_ca
    openssl ca -config openssl.cnf -in ../client/req.pem -out ../client/cert.pem -notext -batch -extensions client_ca_extensions
    cd ../client
    openssl pkcs12 -export -out keycert.p12 -in cert.pem -inkey key.pem -passout pass:secret
    cd ../
}

if [ "$1" = "generate" ]; then
    echo "Generating SSL certificates for Docker ..."
    generate
elif [ "$1" = "clean" ]; then
    echo "Cleaning up ..."
    clean
else
    usage
fi
